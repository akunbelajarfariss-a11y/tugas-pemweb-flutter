// lib/utils/app_constants.dart

import 'package:flutter/material.dart';

class AppConstants {
  AppConstants._();

  static const String appName = 'Surat Desa Kasongan';
  static const String namaDesa = 'Desa Kasongan';
  static const String kecamatan = 'Kec. Kasongan • Kab. Katingan';
  static const String provinsi = 'Kalimantan Tengah';

  static const String keyDaftarSurat = 'daftar_surat';
  static const String keyCounter = 'nomor_counter';

  static const Color primaryColor = Color(0xFF1A5276);
  static const Color secondaryColor = Color(0xFF2E86C1);
  static const Color accentColor = Color(0xFFF39C12);
  static const Color bgColor = Color(0xFFF0F4F8);

  static const List<String> jenisSuratList = [
    'Surat Keterangan Domisili',
    'Surat Keterangan Tidak Mampu',
    'Surat Keterangan Usaha',
    'Surat Keterangan Kelahiran',
    'Surat Keterangan Kematian',
    'Surat Pengantar KTP',
    'Surat Pengantar KK',
    'Surat Keterangan Beda Nama',
    'Surat Keterangan Belum Menikah',
    'Surat Izin Keramaian',
  ];

  static const List<String> statusList = [
    'Menunggu',
    'Diproses',
    'Selesai',
  ];

  static Color statusColor(String status) {
    switch (status) {
      case 'Menunggu':
        return Colors.orange;
      case 'Diproses':
        return Colors.blue;
      case 'Selesai':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  static IconData statusIcon(String status) {
    switch (status) {
      case 'Menunggu':
        return Icons.hourglass_empty_rounded;
      case 'Diproses':
        return Icons.sync_rounded;
      case 'Selesai':
        return Icons.check_circle_rounded;
      default:
        return Icons.help_outline;
    }
  }
}
